import { Leaf, Heart, Award } from "lucide-react";

export default function About() {
  const features = [
    {
      icon: Leaf,
      title: "Sustainable",
      description: "Eco-friendly farming practices"
    },
    {
      icon: Heart,
      title: "Humane", 
      description: "Ethical animal treatment"
    },
    {
      icon: Award,
      title: "Quality",
      description: "Premium products guaranteed"
    }
  ];

  return (
    <section id="about" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="font-playfair text-4xl md:text-5xl font-bold text-forest mb-6">
              Three Generations of Farming Excellence
            </h2>
            <p className="text-lg text-gray-700 mb-6 leading-relaxed">
              Since 1952, AZOYa Poultry Farm has been a family-owned business dedicated to raising healthy, 
              happy chickens in a natural environment. Our commitment to sustainable farming practices 
              ensures the highest quality products for our community.
            </p>
            <p className="text-lg text-gray-700 mb-8 leading-relaxed">
              We believe in treating our animals with respect, maintaining clean facilities, and providing 
              our customers with fresh, nutritious products they can trust.
            </p>
            
            <div className="grid sm:grid-cols-3 gap-6">
              {features.map((feature, index) => {
                const IconComponent = feature.icon;
                return (
                  <div key={index} className="text-center">
                    <div className="bg-forest text-white w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-3">
                      <IconComponent className="h-8 w-8" />
                    </div>
                    <h3 className="font-semibold text-forest mb-2">{feature.title}</h3>
                    <p className="text-sm text-gray-600">{feature.description}</p>
                  </div>
                );
              })}
            </div>
          </div>
          
          <div className="lg:order-first">
            <img 
              src="https://images.unsplash.com/photo-1548550023-2bdb3c5beed7?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600" 
              alt="Free-range chickens in pasture" 
              className="rounded-2xl shadow-2xl w-full h-auto"
            />
          </div>
        </div>
      </div>
    </section>
  );
}
