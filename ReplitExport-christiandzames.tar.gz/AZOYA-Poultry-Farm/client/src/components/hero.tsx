import { Button } from "@/components/ui/button";

export default function Hero() {
  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      const offset = 80;
      const elementPosition = element.offsetTop - offset;
      window.scrollTo({
        top: elementPosition,
        behavior: 'smooth'
      });
    }
  };

  return (
    <section id="home" className="relative h-screen">
      {/* Background Image */}
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{
          backgroundImage: "url('https://images.unsplash.com/photo-1500595046743-cd271d694d30?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1920&h=1080')"
        }}
      />
      <div className="absolute inset-0 bg-black bg-opacity-40" />
      
      <div className="relative z-10 container mx-auto px-4 h-full flex items-center">
        <div className="max-w-3xl text-white">
          <h1 className="font-playfair text-5xl md:text-7xl font-bold mb-6 leading-tight">
            Fresh From Our Farm to Your Table
          </h1>
          <p className="text-xl md:text-2xl mb-8 leading-relaxed">
            AZOYa Poultry Farm delivers the freshest eggs and highest quality poultry products, 
            raised with care on our sustainable family farm.
          </p>
          <div className="flex flex-col sm:flex-row gap-4">
            <Button 
              onClick={() => scrollToSection('products')}
              className="bg-golden hover:bg-accent-gold text-white px-8 py-4 rounded-lg font-semibold transition-all transform hover:scale-105 text-center"
            >
              View Our Products
            </Button>
            <Button 
              variant="outline"
              onClick={() => scrollToSection('contact')}
              className="border-2 border-white text-white hover:bg-white hover:text-forest px-8 py-4 rounded-lg font-semibold transition-all text-center"
            >
              Contact Us
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}
