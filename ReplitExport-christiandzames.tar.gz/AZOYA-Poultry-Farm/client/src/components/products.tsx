import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Egg, Feather, Drumstick, Sprout } from "lucide-react";

export default function Products() {
  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      const offset = 80;
      const elementPosition = element.offsetTop - offset;
      window.scrollTo({
        top: elementPosition,
        behavior: 'smooth'
      });
    }
  };

  const products = [
    {
      title: "Fresh Eggs",
      description: "Farm-fresh eggs from free-range hens, collected daily and packed with nutrients.",
      price: "$4.50/dozen",
      icon: Egg,
      image: "https://images.unsplash.com/photo-1506976785307-8732e854ad03?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=300"
    },
    {
      title: "Live Chickens",
      description: "Healthy, well-cared-for chickens perfect for starting your own flock.",
      price: "$15-25/bird",
      icon: Feather,
      image: "https://images.unsplash.com/photo-1612817288484-6f916006741a?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=300"
    },
    {
      title: "Fresh Chicken",
      description: "Premium quality, locally processed chicken meat from our farm.",
      price: "$6.99/lb",
      icon: Drumstick,
      image: "https://images.unsplash.com/photo-1604503468506-a8da13d82791?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=300"
    },
    {
      title: "Feed & Supplies",
      description: "High-quality feed and essential supplies for raising healthy chickens.",
      price: "$18/bag",
      icon: Sprout,
      image: "https://images.unsplash.com/photo-1574323347407-f5e1ad6d020b?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=300"
    }
  ];

  return (
    <section id="products" className="py-20 bg-cream">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="font-playfair text-4xl md:text-5xl font-bold text-forest mb-6">
            Our Fresh Products
          </h2>
          <p className="text-xl text-gray-700 max-w-3xl mx-auto">
            From farm-fresh eggs to premium poultry, we offer a complete range of high-quality products 
            to meet all your needs.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {products.map((product, index) => {
            const IconComponent = product.icon;
            return (
              <Card key={index} className="bg-white rounded-2xl shadow-lg overflow-hidden hover:transform hover:scale-105 transition-all duration-300">
                <img 
                  src={product.image} 
                  alt={product.title} 
                  className="w-full h-48 object-cover"
                />
                <CardContent className="p-6">
                  <h3 className="font-playfair text-2xl font-bold text-forest mb-3">{product.title}</h3>
                  <p className="text-gray-600 mb-4">{product.description}</p>
                  <div className="flex justify-between items-center">
                    <span className="text-2xl font-bold text-golden">{product.price}</span>
                    <IconComponent className="h-6 w-6 text-golden" />
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        <div className="text-center mt-12">
          <Button 
            onClick={() => scrollToSection('contact')}
            className="bg-forest hover:bg-green-800 text-white px-8 py-4 rounded-lg font-semibold transition-all transform hover:scale-105"
          >
            Order Now
          </Button>
        </div>
      </div>
    </section>
  );
}
