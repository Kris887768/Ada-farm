import Header from "@/components/header";
import Hero from "@/components/hero";
import About from "@/components/about";
import Products from "@/components/products";
import Gallery from "@/components/gallery";
import Contact from "@/components/contact";
import Footer from "@/components/footer";

export default function Home() {
  return (
    <div className="min-h-screen">
      <title>AZOYa Poultry Farm - Fresh Eggs & Quality Poultry Products</title>
      <meta name="description" content="AZOYa Poultry Farm delivers the freshest eggs and highest quality poultry products, raised with care on our sustainable family farm since 1952." />
      <meta property="og:title" content="AZOYa Poultry Farm - Fresh Eggs & Quality Poultry Products" />
      <meta property="og:description" content="Three generations of farming excellence, delivering fresh eggs and premium poultry products to our community." />
      <Header />
      <Hero />
      <About />
      <Products />
      <Gallery />
      <Contact />
      <Footer />
    </div>
  );
}
