import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { MapPin, Star, ArrowRight } from "lucide-react";
import { Link } from "wouter";
import type { Farmer } from "@shared/schema";

interface FarmerCardProps {
  farmer: Farmer;
}

export default function FarmerCard({ farmer }: FarmerCardProps) {
  return (
    <Card className="overflow-hidden hover:shadow-xl transition-shadow">
      {farmer.imageUrl && (
        <img
          src={farmer.imageUrl}
          alt={farmer.name}
          className="w-full h-48 object-cover"
        />
      )}
      
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-xl font-semibold text-gray-900">{farmer.name}</h3>
          <div className="flex flex-wrap gap-1">
            {farmer.certifications.map((cert) => (
              <Badge key={cert} variant="secondary" className="bg-pale-green text-forest text-xs">
                {cert}
              </Badge>
            ))}
          </div>
        </div>
        
        <p className="text-gray-600 mb-4">{farmer.description}</p>
        
        <div className="flex items-center text-sm text-gray-500 mb-4">
          <MapPin className="h-4 w-4 mr-2" />
          <span>{farmer.location}</span>
        </div>
        
        <div className="flex flex-wrap gap-2 mb-4">
          {farmer.specialties.map((specialty) => (
            <Badge key={specialty} variant="outline" className="text-xs">
              {specialty}
            </Badge>
          ))}
        </div>
        
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <div className="flex text-yellow-400">
              {[...Array(5)].map((_, i) => (
                <Star
                  key={i}
                  className={`h-4 w-4 ${
                    i < Math.floor(parseFloat(farmer.rating))
                      ? "fill-current"
                      : "text-gray-300"
                  }`}
                />
              ))}
            </div>
            <span className="ml-2 text-sm text-gray-600">
              ({farmer.reviewCount} reviews)
            </span>
          </div>
          <Link href={`/farmers/${farmer.id}`}>
            <Button variant="ghost" className="text-forest hover:text-sage font-medium p-0">
              View Profile <ArrowRight className="h-4 w-4 ml-1" />
            </Button>
          </Link>
        </div>
      </CardContent>
    </Card>
  );
}
