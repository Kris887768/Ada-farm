import { Link } from "wouter";
import { Sprout } from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-forest text-white py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="md:col-span-2">
            <div className="flex items-center mb-4">
              <Sprout className="h-8 w-8 mr-2" />
              <h4 className="text-2xl font-bold">Ada Farmers</h4>
            </div>
            <p className="text-gray-300 mb-4 max-w-md">
              Connecting local Ada farmers with the community, bringing fresh, seasonal produce directly from farm to table.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-300 hover:text-white transition-colors">
                <i className="fab fa-facebook text-xl"></i>
              </a>
              <a href="#" className="text-gray-300 hover:text-white transition-colors">
                <i className="fab fa-instagram text-xl"></i>
              </a>
              <a href="#" className="text-gray-300 hover:text-white transition-colors">
                <i className="fab fa-twitter text-xl"></i>
              </a>
            </div>
          </div>

          <div>
            <h5 className="font-semibold text-lg mb-4">For Buyers</h5>
            <ul className="space-y-2 text-gray-300">
              <li>
                <Link href="/farmers" className="hover:text-white transition-colors">
                  Browse Farmers
                </Link>
              </li>
              <li>
                <Link href="/products" className="hover:text-white transition-colors">
                  Search Products
                </Link>
              </li>
              <li>
                <a href="#seasonal" className="hover:text-white transition-colors">
                  Seasonal Guide
                </a>
              </li>
              <li>
                <a href="#how-it-works" className="hover:text-white transition-colors">
                  How It Works
                </a>
              </li>
            </ul>
          </div>

          <div>
            <h5 className="font-semibold text-lg mb-4">For Farmers</h5>
            <ul className="space-y-2 text-gray-300">
              <li>
                <a href="#join" className="hover:text-white transition-colors">
                  Join Our Platform
                </a>
              </li>
              <li>
                <a href="#pricing" className="hover:text-white transition-colors">
                  Pricing
                </a>
              </li>
              <li>
                <a href="#resources" className="hover:text-white transition-colors">
                  Resources
                </a>
              </li>
              <li>
                <a href="#support" className="hover:text-white transition-colors">
                  Support
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-sage pt-8 mt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-gray-300 text-sm">&copy; 2024 Ada Farmers. All rights reserved.</p>
          <div className="flex space-x-6 mt-4 md:mt-0">
            <a href="#privacy" className="text-gray-300 hover:text-white text-sm transition-colors">
              Privacy Policy
            </a>
            <a href="#terms" className="text-gray-300 hover:text-white text-sm transition-colors">
              Terms of Service
            </a>
            <a href="#contact" className="text-gray-300 hover:text-white text-sm transition-colors">
              Contact
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
