import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Sprout, Menu } from "lucide-react";
import { useState } from "react";

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <header className="bg-white shadow-sm border-b border-gray-200 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center space-x-4">
            <Link href="/" className="flex items-center">
              <Sprout className="h-8 w-8 text-forest mr-2" />
              <h1 className="text-2xl font-bold text-forest">Ada Farmers</h1>
            </Link>
          </div>
          
          <nav className="hidden md:flex space-x-8">
            <Link href="/farmers" className="text-gray-600 hover:text-forest transition-colors font-medium">
              Browse Farmers
            </Link>
            <Link href="/products" className="text-gray-600 hover:text-forest transition-colors font-medium">
              Products
            </Link>
            <a href="#seasonal" className="text-gray-600 hover:text-forest transition-colors font-medium">
              Seasonal Guide
            </a>
            <a href="#about" className="text-gray-600 hover:text-forest transition-colors font-medium">
              About
            </a>
          </nav>

          <div className="flex items-center space-x-4">
            <button
              className="md:hidden text-gray-600 hover:text-forest"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              <Menu className="h-6 w-6" />
            </button>
            <Button className="hidden md:inline-flex bg-forest text-white hover:bg-sage transition-colors font-medium">
              Join as Farmer
            </Button>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden border-t border-gray-200 py-4">
            <nav className="flex flex-col space-y-4">
              <Link href="/farmers" className="text-gray-600 hover:text-forest transition-colors font-medium">
                Browse Farmers
              </Link>
              <Link href="/products" className="text-gray-600 hover:text-forest transition-colors font-medium">
                Products
              </Link>
              <a href="#seasonal" className="text-gray-600 hover:text-forest transition-colors font-medium">
                Seasonal Guide
              </a>
              <a href="#about" className="text-gray-600 hover:text-forest transition-colors font-medium">
                About
              </a>
              <Button className="bg-forest text-white hover:bg-sage transition-colors font-medium w-full">
                Join as Farmer
              </Button>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
}
