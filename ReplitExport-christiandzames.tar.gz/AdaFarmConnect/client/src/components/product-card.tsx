import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { User, MapPin, Calendar } from "lucide-react";
import type { Product, Farmer } from "@shared/schema";

interface ProductCardProps {
  product: Product & { farmer: Farmer };
}

export default function ProductCard({ product }: ProductCardProps) {
  const getAvailabilityBadge = () => {
    if (product.isAvailable) {
      return <Badge className="bg-green-500 text-white">Available</Badge>;
    } else {
      return <Badge className="bg-orange-500 text-white">Pre-order</Badge>;
    }
  };

  const getSeasonText = () => {
    if (product.seasonStart && product.seasonEnd) {
      return `Available ${product.seasonStart}-${product.seasonEnd}`;
    } else if (product.seasonStart) {
      return `Available starting ${product.seasonStart}`;
    }
    return "Available year-round";
  };

  return (
    <Card className="overflow-hidden hover:shadow-lg transition-shadow">
      <div className="relative">
        {product.imageUrl && (
          <img
            src={product.imageUrl}
            alt={product.name}
            className="w-full h-48 object-cover"
          />
        )}
        <div className="absolute top-3 left-3">
          {getAvailabilityBadge()}
        </div>
        {product.isOrganic && (
          <div className="absolute top-3 right-3">
            <Badge className="bg-pale-green text-forest">Organic</Badge>
          </div>
        )}
      </div>
      
      <CardContent className="p-4">
        <div className="flex items-start justify-between mb-2">
          <h3 className="font-semibold text-lg text-gray-900">{product.name}</h3>
          <span className="font-bold text-forest text-lg">
            ₵{product.price}/{product.unit}
          </span>
        </div>
        
        <p className="text-sm text-gray-600 mb-3">{product.description}</p>
        
        <div className="flex items-center text-sm text-gray-500 mb-3">
          <User className="h-4 w-4 mr-1" />
          <span>{product.farmer.name}</span>
          <span className="mx-2">•</span>
          <MapPin className="h-4 w-4 mr-1" />
          <span>{product.farmer.location.split(' ')[0]} mi</span>
        </div>
        
        <div className="flex items-center justify-between">
          <div className="flex items-center text-sm">
            <Calendar className="h-4 w-4 text-gray-400 mr-1" />
            <span className="text-gray-600">{getSeasonText()}</span>
          </div>
          <Button
            size="sm"
            className="bg-forest text-white hover:bg-sage transition-colors font-medium"
          >
            Contact Farmer
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
