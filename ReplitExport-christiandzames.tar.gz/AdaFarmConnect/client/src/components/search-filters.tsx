import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Search } from "lucide-react";

interface SearchFiltersProps {
  filters: {
    search: string;
    category: string;
    isAvailable: boolean;
    isOrganic: boolean | undefined;
  };
  onFiltersChange: (filters: {
    search: string;
    category: string;
    isAvailable: boolean;
    isOrganic: boolean | undefined;
  }) => void;
}

export default function SearchFilters({ filters, onFiltersChange }: SearchFiltersProps) {
  const updateFilter = (key: string, value: any) => {
    onFiltersChange({ ...filters, [key]: value });
  };

  return (
    <Card className="sticky top-24">
      <CardHeader>
        <CardTitle className="text-lg">Refine Your Search</CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div>
          <Label className="text-sm font-medium text-gray-700 mb-2">Search Products</Label>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            <Input
              placeholder="Search products..."
              value={filters.search}
              onChange={(e) => updateFilter("search", e.target.value)}
              className="pl-10"
            />
          </div>
        </div>

        <div>
          <Label className="text-sm font-medium text-gray-700 mb-2">Product Type</Label>
          <div className="space-y-2">
            {[
              { value: "", label: "All Categories" },
              { value: "vegetables", label: "Vegetables" },
              { value: "fruits", label: "Fruits" },
              { value: "herbs", label: "Herbs" },
              { value: "grains", label: "Grains" },
            ].map(({ value, label }) => (
              <div key={value} className="flex items-center space-x-2">
                <Checkbox
                  id={`category-${value}`}
                  checked={filters.category === value}
                  onCheckedChange={() => updateFilter("category", value)}
                />
                <Label htmlFor={`category-${value}`} className="text-sm">
                  {label}
                </Label>
              </div>
            ))}
          </div>
        </div>

        <div>
          <Label className="text-sm font-medium text-gray-700 mb-2">Availability</Label>
          <RadioGroup
            value={filters.isAvailable.toString()}
            onValueChange={(value) => updateFilter("isAvailable", value === "true")}
          >
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="true" id="available" />
              <Label htmlFor="available" className="text-sm">Available Now</Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="false" id="preorder" />
              <Label htmlFor="preorder" className="text-sm">Pre-order</Label>
            </div>
          </RadioGroup>
        </div>

        <div>
          <Label className="text-sm font-medium text-gray-700 mb-2">Distance</Label>
          <Select>
            <SelectTrigger>
              <SelectValue placeholder="Within 5 miles" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="5">Within 5 miles</SelectItem>
              <SelectItem value="10">Within 10 miles</SelectItem>
              <SelectItem value="20">Within 20 miles</SelectItem>
              <SelectItem value="any">Any distance</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div>
          <Label className="text-sm font-medium text-gray-700 mb-2">Farming Method</Label>
          <div className="space-y-2">
            <div className="flex items-center space-x-2">
              <Checkbox
                id="organic"
                checked={filters.isOrganic === true}
                onCheckedChange={(checked) =>
                  updateFilter("isOrganic", checked ? true : undefined)
                }
              />
              <Label htmlFor="organic" className="text-sm">Organic Certified</Label>
            </div>
            <div className="flex items-center space-x-2">
              <Checkbox
                id="pesticide-free"
                checked={filters.isOrganic === false}
                onCheckedChange={(checked) =>
                  updateFilter("isOrganic", checked ? false : undefined)
                }
              />
              <Label htmlFor="pesticide-free" className="text-sm">Conventional</Label>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
