import { useQuery } from "@tanstack/react-query";
import { useRoute } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import ProductCard from "@/components/product-card";
import { Star, MapPin, Phone, Mail } from "lucide-react";
import type { Farmer, Product } from "@shared/schema";

export default function FarmerProfile() {
  const [match, params] = useRoute("/farmers/:id");
  const farmerId = params?.id ? parseInt(params.id) : null;

  const { data: farmer, isLoading: farmerLoading } = useQuery<Farmer>({
    queryKey: ["/api/farmers", farmerId],
    enabled: !!farmerId,
  });

  const { data: products = [], isLoading: productsLoading } = useQuery<Product[]>({
    queryKey: ["/api/farmers", farmerId, "products"],
    enabled: !!farmerId,
  });

  if (!match || !farmerId) {
    return (
      <div className="min-h-screen bg-gray-50 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <p className="text-gray-600">Invalid farmer ID</p>
          </div>
        </div>
      </div>
    );
  }

  if (farmerLoading) {
    return (
      <div className="min-h-screen bg-gray-50 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <div className="animate-pulse">Loading farmer profile...</div>
          </div>
        </div>
      </div>
    );
  }

  if (!farmer) {
    return (
      <div className="min-h-screen bg-gray-50 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <p className="text-gray-600">Farmer not found</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Farmer Header */}
        <Card className="mb-8">
          <CardContent className="p-8">
            <div className="flex flex-col lg:flex-row gap-8">
              <div className="lg:w-1/3">
                {farmer.imageUrl && (
                  <img
                    src={farmer.imageUrl}
                    alt={farmer.name}
                    className="w-full h-64 object-cover rounded-lg"
                  />
                )}
              </div>
              <div className="lg:w-2/3">
                <div className="flex items-center justify-between mb-4">
                  <h1 className="text-3xl font-bold text-gray-900">{farmer.name}</h1>
                  <div className="flex flex-wrap gap-2">
                    {farmer.certifications.map((cert) => (
                      <Badge key={cert} variant="secondary" className="bg-pale-green text-forest">
                        {cert}
                      </Badge>
                    ))}
                  </div>
                </div>
                
                <p className="text-gray-600 mb-6 text-lg">{farmer.description}</p>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                  <div className="flex items-center text-gray-600">
                    <MapPin className="h-5 w-5 mr-2" />
                    <span>{farmer.location}</span>
                  </div>
                  {farmer.phone && (
                    <div className="flex items-center text-gray-600">
                      <Phone className="h-5 w-5 mr-2" />
                      <span>{farmer.phone}</span>
                    </div>
                  )}
                  {farmer.email && (
                    <div className="flex items-center text-gray-600">
                      <Mail className="h-5 w-5 mr-2" />
                      <span>{farmer.email}</span>
                    </div>
                  )}
                  <div className="flex items-center">
                    <div className="flex text-yellow-400 mr-2">
                      {[...Array(5)].map((_, i) => (
                        <Star
                          key={i}
                          className={`h-4 w-4 ${
                            i < Math.floor(parseFloat(farmer.rating))
                              ? "fill-current"
                              : "text-gray-300"
                          }`}
                        />
                      ))}
                    </div>
                    <span className="text-sm text-gray-600">
                      {farmer.rating} ({farmer.reviewCount} reviews)
                    </span>
                  </div>
                </div>

                <div className="mb-6">
                  <h3 className="font-semibold text-gray-900 mb-2">Specialties</h3>
                  <div className="flex flex-wrap gap-2">
                    {farmer.specialties.map((specialty) => (
                      <Badge key={specialty} variant="outline">
                        {specialty}
                      </Badge>
                    ))}
                  </div>
                </div>

                <div className="flex gap-4">
                  {farmer.phone && (
                    <Button className="bg-forest hover:bg-sage">
                      <Phone className="h-4 w-4 mr-2" />
                      Call Farmer
                    </Button>
                  )}
                  {farmer.email && (
                    <Button variant="outline" className="border-forest text-forest hover:bg-forest hover:text-white">
                      <Mail className="h-4 w-4 mr-2" />
                      Send Email
                    </Button>
                  )}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Products Section */}
        <div>
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Available Products</h2>
          
          {productsLoading ? (
            <div className="text-center py-8">
              <div className="animate-pulse">Loading products...</div>
            </div>
          ) : products.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-gray-600">No products available from this farmer.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {products.map((product) => (
                <ProductCard
                  key={product.id}
                  product={{ ...product, farmer }}
                />
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
