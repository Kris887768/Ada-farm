import { useQuery } from "@tanstack/react-query";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import FarmerCard from "@/components/farmer-card";
import ProductCard from "@/components/product-card";
import ContactForm from "@/components/contact-form";
import { Sprout, Search, MapPin, Star, Calendar, CheckCircle } from "lucide-react";
import { Link } from "wouter";
import type { Farmer, Product } from "@shared/schema";

export default function Home() {
  const { data: farmers = [] } = useQuery<Farmer[]>({
    queryKey: ["/api/farmers"],
  });

  const { data: productsWithFarmer = [] } = useQuery<Array<Product & { farmer: Farmer }>>({
    queryKey: ["/api/products/with-farmer"],
  });

  const featuredFarmers = farmers.slice(0, 3);
  const featuredProducts = productsWithFarmer.slice(0, 6);

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-forest text-white">
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat opacity-20" 
          style={{
            backgroundImage: "url('https://images.unsplash.com/photo-1574323347407-f5e1ad6d020b?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=800')"
          }}
        />
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
          <div className="text-center max-w-3xl mx-auto">
            <h1 className="text-5xl md:text-6xl font-bold mb-6">
              Fresh From Farm to Your Table
            </h1>
            <p className="text-xl md:text-2xl text-gray-200 mb-12 font-light">
              Connect directly with local Ada farmers and discover the freshest seasonal produce in your area
            </p>
            
            <Card className="bg-white rounded-2xl p-6 shadow-2xl">
              <CardContent className="p-0">
                <div className="flex flex-col md:flex-row gap-4">
                  <div className="flex-1">
                    <label className="block text-sm font-medium text-gray-700 mb-2">What are you looking for?</label>
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                      <Input 
                        placeholder="Search vegetables, fruits, herbs..." 
                        className="pl-10 pr-4 py-3 border border-gray-300 focus:ring-2 focus:ring-forest focus:border-transparent text-gray-900"
                      />
                    </div>
                  </div>
                  <div className="md:w-48">
                    <label className="block text-sm font-medium text-gray-700 mb-2">Location</label>
                    <div className="relative">
                      <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4 z-10" />
                      <Select>
                        <SelectTrigger className="pl-10 pr-4 py-3 border border-gray-300 focus:ring-2 focus:ring-forest focus:border-transparent text-gray-900">
                          <SelectValue placeholder="All Areas" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">All Areas</SelectItem>
                          <SelectItem value="downtown">Downtown Ada</SelectItem>
                          <SelectItem value="north">North Ada</SelectItem>
                          <SelectItem value="east">East Ada</SelectItem>
                          <SelectItem value="west">West Ada</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <Link href="/products">
                    <Button className="bg-forest text-white px-8 py-3 hover:bg-sage transition-colors font-semibold h-12">
                      Search
                    </Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Featured Farmers */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Featured Local Farmers</h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Meet the passionate growers who bring you the freshest produce straight from their fields
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {featuredFarmers.map((farmer) => (
              <FarmerCard key={farmer.id} farmer={farmer} />
            ))}
          </div>

          <div className="text-center mt-12">
            <Link href="/farmers">
              <Button variant="outline" className="border-forest text-forest hover:bg-forest hover:text-white">
                View All Farmers
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Fresh Products Available Now</h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Browse seasonal produce from local Ada farmers
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {featuredProducts.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>

          <div className="text-center mt-12">
            <Link href="/products">
              <Button variant="outline" className="border-forest text-forest hover:bg-forest hover:text-white">
                View All Products
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Seasonal Guide */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">What's in Season</h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Discover the best produce available throughout the year in Ada
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card className="bg-gradient-to-br from-green-50 to-green-100 border-green-200">
              <CardContent className="p-6">
                <div className="flex items-center mb-4">
                  <Sprout className="h-6 w-6 text-green-600 mr-3" />
                  <h3 className="font-semibold text-xl text-gray-900">Dry Season</h3>
                </div>
                <ul className="space-y-2 text-gray-700">
                  {["Tomatoes", "Onions", "Irish Potatoes", "Green Pepper", "Maize"].map((item) => (
                    <li key={item} className="flex items-center">
                      <CheckCircle className="h-4 w-4 text-green-600 mr-2" />
                      {item}
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-yellow-50 to-yellow-100 border-yellow-200">
              <CardContent className="p-6">
                <div className="flex items-center mb-4">
                  <div className="h-6 w-6 bg-yellow-600 rounded-full mr-3" />
                  <h3 className="font-semibold text-xl text-gray-900">Rainy Season</h3>
                </div>
                <ul className="space-y-2 text-gray-700">
                  {["Okro", "Pepper", "Chilli Pepper", "Maize", "Tomatoes"].map((item) => (
                    <li key={item} className="flex items-center">
                      <CheckCircle className="h-4 w-4 text-yellow-600 mr-2" />
                      {item}
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-orange-50 to-orange-100 border-orange-200">
              <CardContent className="p-6">
                <div className="flex items-center mb-4">
                  <div className="h-6 w-6 bg-orange-600 rounded-full mr-3" />
                  <h3 className="font-semibold text-xl text-gray-900">Peak Season</h3>
                </div>
                <ul className="space-y-2 text-gray-700">
                  {["All Peppers", "Fresh Maize", "Okro", "Onions", "Irish Potatoes"].map((item) => (
                    <li key={item} className="flex items-center">
                      <CheckCircle className="h-4 w-4 text-orange-600 mr-2" />
                      {item}
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-blue-50 to-blue-100 border-blue-200">
              <CardContent className="p-6">
                <div className="flex items-center mb-4">
                  <div className="h-6 w-6 bg-blue-600 rounded-full mr-3" />
                  <h3 className="font-semibold text-xl text-gray-900">Year Round</h3>
                </div>
                <ul className="space-y-2 text-gray-700">
                  {["Onions", "Irish Potatoes", "Ginger", "Garlic", "Hot Pepper"].map((item) => (
                    <li key={item} className="flex items-center">
                      <CheckCircle className="h-4 w-4 text-blue-600 mr-2" />
                      {item}
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Get in Touch</h2>
            <p className="text-xl text-gray-600">
              Have questions or special requests? Contact our farmers directly or reach out to us
            </p>
          </div>

          <ContactForm />
        </div>
      </section>
    </div>
  );
}
