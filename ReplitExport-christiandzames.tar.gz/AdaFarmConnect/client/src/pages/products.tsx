import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import ProductCard from "@/components/product-card";
import SearchFilters from "@/components/search-filters";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import type { Product, Farmer } from "@shared/schema";

export default function Products() {
  const [filters, setFilters] = useState({
    search: "",
    category: "",
    isAvailable: true,
    isOrganic: undefined as boolean | undefined,
  });
  const [sortBy, setSortBy] = useState("featured");

  const queryParams = new URLSearchParams();
  if (filters.search) queryParams.append("search", filters.search);
  if (filters.category) queryParams.append("category", filters.category);
  if (filters.isAvailable !== undefined) queryParams.append("isAvailable", filters.isAvailable.toString());
  if (filters.isOrganic !== undefined) queryParams.append("isOrganic", filters.isOrganic.toString());

  const { data: productsWithFarmer = [], isLoading } = useQuery<Array<Product & { farmer: Farmer }>>({
    queryKey: ["/api/products/with-farmer", queryParams.toString()],
  });

  // Sort products based on selected criteria
  const sortedProducts = [...productsWithFarmer].sort((a, b) => {
    switch (sortBy) {
      case "price-low":
        return parseFloat(a.price) - parseFloat(b.price);
      case "price-high":
        return parseFloat(b.price) - parseFloat(a.price);
      case "name":
        return a.name.localeCompare(b.name);
      default:
        return 0; // featured order
    }
  });

  // Filter products based on current filters
  const filteredProducts = sortedProducts.filter(product => {
    if (filters.search && !product.name.toLowerCase().includes(filters.search.toLowerCase()) &&
        !product.description.toLowerCase().includes(filters.search.toLowerCase())) {
      return false;
    }
    if (filters.category && product.category !== filters.category) {
      return false;
    }
    if (filters.isAvailable !== undefined && product.isAvailable !== filters.isAvailable) {
      return false;
    }
    if (filters.isOrganic !== undefined && product.isOrganic !== filters.isOrganic) {
      return false;
    }
    return true;
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <div className="animate-pulse">Loading products...</div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Fresh Products Available Now</h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Browse seasonal produce from local Ada farmers
          </p>
        </div>

        <div className="flex flex-col lg:flex-row gap-8">
          {/* Filters Sidebar */}
          <div className="lg:w-1/4">
            <SearchFilters filters={filters} onFiltersChange={setFilters} />
          </div>

          {/* Products Grid */}
          <div className="lg:w-3/4">
            <div className="flex items-center justify-between mb-6">
              <p className="text-gray-600">
                Showing <span className="font-semibold">{filteredProducts.length}</span> products
              </p>
              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger className="w-48">
                  <SelectValue placeholder="Sort by" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="featured">Sort by: Featured</SelectItem>
                  <SelectItem value="price-low">Price: Low to High</SelectItem>
                  <SelectItem value="price-high">Price: High to Low</SelectItem>
                  <SelectItem value="name">Name: A to Z</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {filteredProducts.length === 0 ? (
              <div className="text-center py-12">
                <p className="text-gray-600">No products found matching your criteria.</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                {filteredProducts.map((product) => (
                  <ProductCard key={product.id} product={product} />
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
