import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertContactMessageSchema, insertFarmerSchema, insertProductSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Get all farmers
  app.get("/api/farmers", async (req, res) => {
    try {
      const farmers = await storage.getFarmers();
      res.json(farmers);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch farmers" });
    }
  });

  // Get farmer by ID
  app.get("/api/farmers/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const farmer = await storage.getFarmer(id);
      
      if (!farmer) {
        return res.status(404).json({ message: "Farmer not found" });
      }
      
      res.json(farmer);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch farmer" });
    }
  });

  // Create farmer
  app.post("/api/farmers", async (req, res) => {
    try {
      const validatedData = insertFarmerSchema.parse(req.body);
      const farmer = await storage.createFarmer(validatedData);
      res.status(201).json(farmer);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid farmer data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create farmer" });
    }
  });

  // Get products with optional filters
  app.get("/api/products", async (req, res) => {
    try {
      const filters = {
        category: req.query.category as string,
        farmerId: req.query.farmerId ? parseInt(req.query.farmerId as string) : undefined,
        isAvailable: req.query.isAvailable ? req.query.isAvailable === 'true' : undefined,
        isOrganic: req.query.isOrganic ? req.query.isOrganic === 'true' : undefined,
        search: req.query.search as string,
      };

      // Remove undefined values
      const cleanFilters = Object.fromEntries(
        Object.entries(filters).filter(([_, value]) => value !== undefined)
      );

      const products = await storage.getProducts(cleanFilters);
      res.json(products);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch products" });
    }
  });

  // Get products with farmer information
  app.get("/api/products/with-farmer", async (req, res) => {
    try {
      const productsWithFarmer = await storage.getProductsWithFarmer();
      res.json(productsWithFarmer);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch products with farmer info" });
    }
  });

  // Get product by ID
  app.get("/api/products/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const product = await storage.getProduct(id);
      
      if (!product) {
        return res.status(404).json({ message: "Product not found" });
      }
      
      res.json(product);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch product" });
    }
  });

  // Create product
  app.post("/api/products", async (req, res) => {
    try {
      const validatedData = insertProductSchema.parse(req.body);
      const product = await storage.createProduct(validatedData);
      res.status(201).json(product);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid product data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create product" });
    }
  });

  // Get products by farmer ID
  app.get("/api/farmers/:id/products", async (req, res) => {
    try {
      const farmerId = parseInt(req.params.id);
      const products = await storage.getProducts({ farmerId });
      res.json(products);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch farmer products" });
    }
  });

  // Create contact message
  app.post("/api/contact", async (req, res) => {
    try {
      const validatedData = insertContactMessageSchema.parse(req.body);
      const message = await storage.createContactMessage(validatedData);
      res.status(201).json(message);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid contact data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to send message" });
    }
  });

  // Get all contact messages (for admin)
  app.get("/api/contact", async (req, res) => {
    try {
      const messages = await storage.getContactMessages();
      res.json(messages);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch messages" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
