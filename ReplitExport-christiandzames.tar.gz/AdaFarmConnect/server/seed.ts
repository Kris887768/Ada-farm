import { db } from "./db";
import { farmers, products } from "@shared/schema";

async function seedDatabase() {
  console.log("Seeding database with sample data...");

  // Insert farmers
  const farmerData = [
    {
      name: "Christian's Organic Farm",
      description: "Specializing in fresh tomatoes, peppers, and seasonal vegetables. Growing pesticide-free produce with traditional farming methods.",
      location: "2.5 miles from downtown Ada",
      phone: "0204135632",
      email: "christiandzamesi@gmail.com",
      certifications: ["Organic Certified"],
      specialties: ["Tomatoes", "Peppers", "Onions"],
      imageUrl: "https://images.unsplash.com/photo-1595113316349-9fa4eb24f884?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300",
      rating: "4.9",
      reviewCount: 47,
      isActive: true,
    },
    {
      name: "Ada Valley Farm",
      description: "Traditional farming methods focusing on maize, okro, and seasonal vegetables. Fresh produce harvested daily for local community.",
      location: "4.1 miles from downtown Ada",
      phone: "(233) 234-5678",
      email: "adavalley@gmail.com",
      certifications: ["Traditional Methods"],
      specialties: ["Maize", "Okro", "Potatoes"],
      imageUrl: "https://images.unsplash.com/photo-1566740933430-b5e70b06d2d5?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300",
      rating: "4.8",
      reviewCount: 32,
      isActive: true,
    },
    {
      name: "Green Pepper Gardens",
      description: "Specialized in growing various pepper varieties including green peppers and chilli peppers. Known for high-quality spicy produce.",
      location: "3.7 miles from downtown Ada",
      phone: "(233) 345-6789",
      email: "greenpepper@gmail.com",
      certifications: ["Pepper Specialist"],
      specialties: ["Green Peppers", "Chilli Peppers", "Hot Peppers"],
      imageUrl: "https://images.unsplash.com/photo-1581833971358-2c8b550f87b3?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300",
      rating: "5.0",
      reviewCount: 68,
      isActive: true,
    },
  ];

  const insertedFarmers = await db.insert(farmers).values(farmerData).returning();
  console.log(`Inserted ${insertedFarmers.length} farmers`);

  // Insert products
  const productData = [
    {
      farmerId: insertedFarmers[0].id,
      name: "Fresh Tomatoes",
      description: "Sweet, juicy red tomatoes perfect for stews, salads and cooking. Harvested daily for maximum freshness.",
      price: "15.00",
      unit: "kg",
      category: "vegetables",
      imageUrl: "https://images.unsplash.com/photo-1518977676601-b53f82aba655?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250",
      isAvailable: true,
      isOrganic: true,
      seasonStart: "March",
      seasonEnd: "November",
      tags: ["fresh", "daily-harvest"],
    },
    {
      farmerId: insertedFarmers[0].id,
      name: "Red Pepper",
      description: "Fresh red peppers with excellent flavor. Perfect for cooking and spicing up meals.",
      price: "25.00",
      unit: "kg",
      category: "vegetables",
      imageUrl: "https://images.unsplash.com/photo-1563565375-f3fdfdbefa83?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250",
      isAvailable: true,
      isOrganic: true,
      seasonStart: "April",
      seasonEnd: "December",
      tags: ["spicy", "fresh"],
    },
    {
      farmerId: insertedFarmers[0].id,
      name: "Fresh Onions",
      description: "Quality onions with strong flavor. Essential for every kitchen and cooking.",
      price: "12.00",
      unit: "kg",
      category: "vegetables",
      imageUrl: "https://images.unsplash.com/photo-1518977676601-b53f82aba655?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250",
      isAvailable: true,
      isOrganic: true,
      seasonStart: "January",
      seasonEnd: "December",
      tags: ["essential", "cooking"],
    },
    {
      farmerId: insertedFarmers[1].id,
      name: "Fresh Maize",
      description: "Sweet yellow maize corn. Excellent for roasting, boiling or making kenkey.",
      price: "8.00",
      unit: "kg",
      category: "grains",
      imageUrl: "https://images.unsplash.com/photo-1551754655-cd27e38d2076?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250",
      isAvailable: true,
      isOrganic: false,
      seasonStart: "May",
      seasonEnd: "September",
      tags: ["sweet", "staple"],
    },
    {
      farmerId: insertedFarmers[1].id,
      name: "Fresh Okro",
      description: "Green okro perfect for preparing okro stew and soups. Very fresh and tender.",
      price: "18.00",
      unit: "kg",
      category: "vegetables",
      imageUrl: "https://images.unsplash.com/photo-1598170845058-32b9d6a5da37?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250",
      isAvailable: true,
      isOrganic: false,
      seasonStart: "April",
      seasonEnd: "November",
      tags: ["tender", "soup"],
    },
    {
      farmerId: insertedFarmers[1].id,
      name: "Irish Potatoes",
      description: "Quality Irish potatoes perfect for frying, boiling or making chips.",
      price: "10.00",
      unit: "kg",
      category: "vegetables",
      imageUrl: "https://images.unsplash.com/photo-1598170845058-32b9d6a5da37?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250",
      isAvailable: true,
      isOrganic: false,
      seasonStart: "January",
      seasonEnd: "December",
      tags: ["versatile", "staple"],
    },
    {
      farmerId: insertedFarmers[2].id,
      name: "Green Pepper",
      description: "Fresh green bell peppers with crisp texture. Perfect for stir-fries and salads.",
      price: "22.00",
      unit: "kg",
      category: "vegetables",
      imageUrl: "https://images.unsplash.com/photo-1563565375-f3fdfdbefa83?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250",
      isAvailable: true,
      isOrganic: false,
      seasonStart: "March",
      seasonEnd: "November",
      tags: ["crisp", "fresh"],
    },
    {
      farmerId: insertedFarmers[2].id,
      name: "Chilli Pepper",
      description: "Hot chilli peppers for those who love spicy food. Very hot and flavorful.",
      price: "35.00",
      unit: "kg",
      category: "vegetables",
      imageUrl: "https://images.unsplash.com/photo-1583736647653-bf0c5dc85e39?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250",
      isAvailable: true,
      isOrganic: false,
      seasonStart: "April",
      seasonEnd: "December",
      tags: ["hot", "spicy"],
    },
  ];

  const insertedProducts = await db.insert(products).values(productData).returning();
  console.log(`Inserted ${insertedProducts.length} products`);

  console.log("Database seeding completed!");
}

seedDatabase().catch(console.error);